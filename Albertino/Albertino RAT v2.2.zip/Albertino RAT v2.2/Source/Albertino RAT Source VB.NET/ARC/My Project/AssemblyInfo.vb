﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices


<Assembly: AssemblyTitle("Microsoft Library Component")> 

<Assembly: AssemblyVersionAttribute("1.7")> 
<Assembly: AssemblyFileVersionAttribute("1.7")> 