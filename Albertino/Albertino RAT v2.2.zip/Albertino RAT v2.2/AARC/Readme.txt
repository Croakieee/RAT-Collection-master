PLEASE READ THIS INFORMATION BEFORE USING AARC :
----------------------------------------------------------------------------------
1- Before using AARC please read the help file. You can reach to the help file by pressing Info button in Menu Strip. As you will see there is enough information there for use and solving your problems. 

2- All kind of user problems with AARC are discussed in http://www.hackforums.net 
Before writing to the forum I suggest you to read the help file once more and if you can't find the answer in the help file write it to the forum under the right topic correctly with details such as your operating system, error message etc. so I can solve the problem fast and properly. I don�t answer any kind of questions like "why cant i connect to the server what should I do?"

3- AARC will not send any Kellogg files or any passwords to your email address. AARC is a "Albertino Remote Administrator Tool Creator" you can only get the Kellogg files and passwords you want to learn by connect to the victims PC.

4- You can connect to all PC in your country and other country�s as well. If the client is connected to internet this will be enough.

5- If you cant connect to a client this doesn�t mean that you cannot connect to all clients. Please try new clients and you will see that it will connect. If you still cant connect to a client after trying few times read the help file and try to find where you are making a mistake and feel free to ask us questions if you still have problems.
 
6- If yours or your clients PC is being forced to closing after you started AARC server this is not AARC fault because some kind of worm virus like msblast can infiltrate to PC which doesn�t have security patches. 

7-This software is provided 'as-is', without any express or implied warranty.  In no event will the authors be held liable for any damages arising from the use of this software. The software is for educational purposes only, all illegal activities are prohibited.

----------------------------------------------------------------------------------
