<?php

$servername = "localhost"; //Host
$username = "admin"; //Host Username
$password = "admin"; //Host Password
$dbname = "krat"; //DataBase Name

$Login_Username = "root"; //Youre Username Used To Login .
$Login_Password = "root"; //Youre Password Used To Login .

?>