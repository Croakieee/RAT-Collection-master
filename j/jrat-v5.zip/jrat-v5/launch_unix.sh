#!/bin/bash
java -jar Controller.jar